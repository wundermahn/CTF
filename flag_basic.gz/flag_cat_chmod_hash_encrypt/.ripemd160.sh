#!/bin/bash
# Performs the ripemd160 hashing algorithm on the entered argument

if [ "$1" = "" ]; then
    echo "Ugh. Don't you just hate it when you want to ARGUE and nobody provides you anything to HASH it out?"
fi

if [ "$1" != "" ]; then
    echo -n "$1" | openssl dgst -ripemd160
fi

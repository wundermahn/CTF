#!/bin/bash
# Performs MD5 hashing algorithm on the entered argument

if [ "$1" = "" ]; then
    echo "Ugh. Don't you just hate it when you want to ARGUE and nobody provides you anything to HASH it out?"
fi

if [ "$1" != "" ]; then
    echo -n "$1" | md5sum
fi

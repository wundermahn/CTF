#!/bin/bash
for f in flag.gpg hints_2.txt md5.sh ripemd160.sh sha256.sh whirlpool.sh hide.sh; do mv "$f" ".$f"; done

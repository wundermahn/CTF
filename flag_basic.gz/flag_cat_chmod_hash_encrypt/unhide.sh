#!/bin/bash

###

# THIS IS NOT THE COMMENT YOU ARE LOOKING FOR sike.
# The password is EffTeeDee (FTD)
# TROLOLOLOLOLOLOLOLOLOLOL

###

if [ "$1" = "EffTeeDee" ]; then
    find ./ -type f -name '.*' -execdir sh -c 'mv -i "$0" "./${0#./.}"' {} \;
    echo "Hidden files available."
else
    echo "Ah ah ah...you didn't say the magic word!"
    echo "...er...words!"
    echo "...uhh...letters?"
fi
